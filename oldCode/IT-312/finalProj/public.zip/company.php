<?php require_once("../resources/config.php");  ?>

<?php include(TEMPLATE_FRONT . DS . "header.php");  ?>


<h2 class="text-center">About Us</h3><hr>

<div class="container">
    <div class="row">
        <div class="col-md-6">
            <h3>Our History</h3>
            <p style="color:black">Formed in 2015 Nerdcore was formed as "Nerd" haven to escape to a collectors and gamers paradise. 
                <br><br>
                Located in Central Washington Nerdcore came about for the gaming mind of Dr. Denise Shaw, 
                a former product champion for Decipher Games specializing in the "Lord of the Rings" trading card game. 
                <br><br>
                On June 16th, 2018 we held a Grand Re-Opening of our new location at 411 North Pine St. This location is bigger and brighter than our previous location.
                We are very excited for this, because more room means more room for games, toys, and collectibles! Make sure to stop by and check it out!
                
            </p>
        </div>
        <div class="col-md-6">
            <h3>Who We Are</h3>
            <p style="color:black">Nerdcore is a place where the intentional enthusiast can pick up the latest Marvel or DC Action Figure or latest Board Game.
                <br><br>
                We offer a full range of Board Games, Table Top Miniature Games as well as Trading Card Games. 
                We keep on hand the best collectible action figures and toys for every level of collector. 
                We host varying game nights through out the week and make check our calendar for updates.
                <br><br>
                Some of these events are the daily tournaments we host. Just to give you a taste, we have a WarHammer 40k event on Wednesday at 5pm and
                a Pokemon/Yu-Gi-Oh event on Saturday at Noon and 3pm respectivitly.
            </p>
        </div>
    </div>
</div>
<br>
<br>
<br>

<style>
    h3 {
        text-align: center;
    }
</style>

<?php include(TEMPLATE_FRONT . DS . "footer.php");  ?>