<?php require_once("../resources/config.php");  ?>

<?php include(TEMPLATE_FRONT . DS . "header.php");  ?>

    <!-- Page Content -->
    <div class="container">

            <div class="text-center">
                <h2>Hello, welcome to Nerdcore Toys and Collectibles&#8482;<br>Located in downtown Ellensburg, Washington!</h1>
                <br>
                <h4>We currently sell all sorts of items ranging from magic items, Yu-Gi-Oh items, Pokemon collectibles and lots more!</h4>
                <h4>We are the only authorized seller in the local area to distribute our items</h4>
            </div>

        <div class="row">
        
            <!-- Categories go here (Below lol)-->
            <?php include(TEMPLATE_FRONT . DS . "side_nav.php");  ?>

            <div class="col-md-9">
                <br>

                <div class="row carousel-holder">
                    <!-- carousel code goes here (below)-->
                    <?php include(TEMPLATE_FRONT . DS . "slider.php");  ?>
                </div>

                <!-- put this on categories page
                <div class="row">

                    <?php get_products();  ?>


                </div>
                -->
                
                <!-- End of row -->

            </div>
                <br>
                <br>
        </div>

    </div>
    <!-- /.container -->
    <br>
    <br>
    <br>
    <div class="container text-center">
        <h3>What We Do</h3>
        <hr>
        <div class="row">
            <div class="col-md-3">
                <a href="event.php" data-size="large" target="_blank">
                    <img src="../resources/uploads/tournament-pic.jpg" height="150" style="width:100%;">
                    <div class="top-left">Daily Tournaments</div>
                    <div class="bottom-left">Hours:<br>M-F: 11am-7pm</div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="event.php">  
                    <img src="../resources/uploads/PokemonGame.jpg" height="150" style="width:100%;">
                    <div class="top-left">Card games for all types!</div>
                    <div class="bottom-left">Want to take on your friend, come here!</div>
                </a>
            </div>
            <div class="col-md-3">
            <a href="shop.php">
                    <img src="../resources/uploads/ThorHammer.jpg" height="150" style="width:100%;">
                    <div class="top-right">Collectibles and Pre-Orders?</div>
                    <div class="bottom-right">New collectible out? It's Here!</div>
                </a>
            </div>
            <div class="col-md-3">
            <a href="event.php" data-size="large" target="_blank">
                    <img src="../resources/uploads/BigEvent.jpg" height="150" style="width:100%;">
                    <div class="top-right">Event Around the Corner?</div>
                    <div class="bottom-right">Contact us and let's start talking!</div>
                </a>
            </div>
        </div>

        <style>

        .top-left {
            position: absolute;
            top: 8px;
            left: 16px;
            color: white;
        }

        .bottom-left {
            position: absolute;
            bottom: 8px;
            left: 16px;
            color: white;
        }

        .top-right {
            position: absolute;
            top: 8px;
            right: 16px;
            color: white;
        }

        /* Bottom right text */
        .bottom-right {
            position: absolute;
            bottom: 8px;
            right: 16px;
            color: white;
        }

        </style>

    </div>
    
    <!-- Beginning of Quotes/Testimonials -->
    <br>
    <br>
    <div class="slideshow-container">
        <h3 class="m_3 text-center">Testimonials</h3>
        <hr>
        <!-- Full-width slides/quotes -->
        <div class="mySlides">
            <q>I love this place! Great items to pick from, the owner is awesome to talk to and it’s just a awesome place to go in, browse, and pick up so awesome toys & collectibles!!!</q>
            <p class="author">- <a href="https://www.facebook.com/pg/NerdcoreToys/reviews/?ref=page_internal">Tyler J. Carlson</a></p>
        </div>

        <div class="mySlides">
            <q>My son was gifted a gift card for his birthday so we had the opportunity to look around for the first time!
                    We will definitely be back, such a neat collection of items and wonderful service!
                    Now he has a giant stuffed piece of pumpkin pie he loves to sleep with every night.</q>
            <p class="author">- <a href="https://www.facebook.com/pg/NerdcoreToys/reviews/?ref=page_internal">Katy Pomeroy</a></p>
        </div>

        <div class="mySlides">
            <q>Incredible inventory and vibe for a specialty game store in a very small town.
                    That said, it is an awesomely retro and vibrant downtown that makes the store part of a great visit.
                    It's in a really old building near the iconic Starlight bar and the Tav, but of course that's revealing that many of the games are popular among college students and adults as well as kids.
                    The owners are a seriously funloving couple who set up game nights and are remarkably adept at locating obscure items and having them shipped.
                    Unlike chain stores, they also have some impressive photorealistic paintings by significant artists.
                    Amazingly knowledgeable about all things games, from board games to collectibles to MPG.</q>
            <p class="author">- <a href="https://www.facebook.com/pg/NerdcoreToys/reviews/?ref=page_internal">Naomi Jeffery Petersen</a></p>
        </div>
        <!-- Dots/bullets/indicators -->
        <div class="dot-container">
            <span class="dot" onclick="currentSlide(1)"></span>
            <span class="dot" onclick="currentSlide(2)"></span>
            <span class="dot" onclick="currentSlide(3)"></span>
        </div>
    </div>
    <div>
        <style>
            * Slideshow container */
                .slideshow-container {

                position: relative;
                background: #f1f1f1f1;

                }
                /* Slides */
                .mySlides {

                display: none;
                padding: 80px;
                text-align: center;

                }
                /* On hover, add a black background color with a little bit see-through */
                .prev:hover, .next:hover {

                background-color: rgba(0,0,0,0.8);
                color: white;

                }
                /* The dot/bullet/indicator container */
                .dot-container {

                text-align: center;
                padding: 20px;
                background: #ddd;

                }
                /* The dots/bullets/indicators */
                .dot {

                cursor: pointer;
                height: 15px;
                width: 15px;
                margin: 0 2px;
                background-color: #bbb;
                border-radius: 50%;
                display: inline-block;
                transition: background-color 0.6s ease;

                }
                /* Add a background color to the active dot/circle */
                .active, .dot:hover {

                background-color: #717171;

                }
                /* Add an italic font style to all quotes */
                q {font-style: italic;}

                /* Add a blue color to the author */
                .author {color: cornflowerblue;}

        </style>

        <script>
            var slideIndex = 1;
            showSlides(slideIndex);
            speed: 500,

            function plusSlides(n) {

                showSlides(slideIndex += n);

            } // func plusSlides end

            function currentSlide(n) {

                showSlides(slideIndex = n);

            } // func currentSlide end

            function showSlides(n) {

                var i;
                var slides = document.getElementsByClassName("mySlides");
                var dots = document.getElementsByClassName("dot");
                if (n > slides.length) {slideIndex = 1}
                if (n < 1) {slideIndex = slides.length}

                for (i = 0; i < slides.length; i++) {

                slides[i].style.display = "none";

                } // for end

                for (i = 0; i < dots.length; i++) {

                dots[i].className = dots[i].className.replace(" active", "");

                } // for end

                slides[slideIndex-1].style.display = "block";
                dots[slideIndex-1].className += " active";

            } // func showSlides end

        </script>
    </div> 
    <!-- End of CSS and JS -->


    <!-- End of Quotes/Testimonials -->

<?php include(TEMPLATE_FRONT . DS . "footer.php");  ?>
