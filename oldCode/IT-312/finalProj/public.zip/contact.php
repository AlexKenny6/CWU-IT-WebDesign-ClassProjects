<?php require_once("../resources/config.php");  ?>

<?php include(TEMPLATE_FRONT . DS . "header.php");  ?>

         <!-- Contact Section -->

        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Contact Us</h2><hr>
                    
                        <div class="col-md-7">
                            <div class="map">
                                <iframe width="100%" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyCtTq2EEwo8e-KPI_Mgs4lsdE39AemVwSU&q=Nerdcore,Ellensburg+WA"></iframe></iframe><br><small>
                                </small>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <p style="color:black" class="text-center">We are looking forward to hearing from you.
                                Please feel free to get in touch via the form or contact links below, we will get back to you as soon as possible.
                                Thank you and have a great day!</p>
                            <div class="address" class="text-center">
                                <br>
                                <p style="color:black">411 North Pine Street<br>Ellensburg, WA. 98926, USA</p>
                                <br>
                                <p style="color:black">Phone: <a href="tel:4258353459">425-835-3459</a></p>
                                <p style="color:black">Email: <span><a href="mailto:nerdcoretoys@gmail.com">nerdcoretoys@gmail.com</a></span></p>
                                <p style="color:black">Follow on: <span><a href="https://www.facebook.com/NerdcoreToys/">Facebook</a></span>, <span><a href="https://twitter.com/nerdcoretoys?lang=en">Twitter</a></span></p>
                            </div>   
                        </div> 

                    <!-- Message Sent if email is successfully sent -->
                    <h3 class="section-subheading">
                        <?php display_message(); ?>
                    </h3>
                </div>
            </div>
            <br>
            <br>
            <br>
            <div class="row">
                <div class="col-lg-12">

                    <?php send_message(); ?>

                    <form action="" method="post" name="sentMessage" id="contactForm" >
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" name="name" class="form-control" placeholder="Your Name *" id="name" required data-validation-required-message="Please enter your name.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group">
                                    <input type="email" name="email" class="form-control" placeholder="Your Email *" id="email" required data-validation-required-message="Please enter your email address.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group">
                                    <input type="text" name="subject" class="form-control" placeholder="Your Subject *" id="subject" required data-validation-required-message="Please enter your subject.">
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <textarea class="form-control" name="message" placeholder="Your Message *" id="message" required data-validation-required-message="Please enter a message."></textarea>
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-lg-12 text-center">
                                <div id="success"></div>
                                <button type="submit" name="submit" class="btn btn-xl">Send Message</button>
                            </div>
                            <br><br><br>
                        </div>
                    </form>


                </div>
            </div>
        </div>

    </div>
    <!-- /.container -->
<?php include(TEMPLATE_FRONT .  "/footer.php");?>