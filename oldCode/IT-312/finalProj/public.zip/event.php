<?php require_once("../resources/config.php");  ?>

<?php include(TEMPLATE_FRONT . DS . "header.php");  ?>


<h2 class="text-center">Events/Social Media Feeds</h3><hr>
        <div id="fb-root"></div>
        <script>(function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.0';
        fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>

    <div class="container">
        <div class="row">
            <div class="col-md-6">
            <h3 class="text-center">Twitter Timelime</h3>
                    <a class="twitter-timeline" data-width="500" data-height="500" data-theme="light" data-link-color="#2B7BB9" href="https://twitter.com/NerdcoreToys?ref_src=twsrc%5Etfw">Tweets by NerdcoreToys</a>
                     <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
            </div>

            <div class="col-md-6">
                <h3 class="text-center">Upcoming Events on Facebook</h3>
                <div class="fb-page" data-href="https://www.facebook.com/NerdcoreToys/" data-tabs="events" data-height="450" data-width="600" data-small-header="true" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
                    <blockquote cite="https://www.facebook.com/NerdcoreToys/" class="fb-xfbml-parse-ignore">
                        <a href="https://www.facebook.com/NerdcoreToys/">Nerdcore Toys and Collectibles</a>
                    </blockquote>
                </div>
            </div>

        </div><!-- End of first row -->

        <br>
        <br>
        <br>

        <div class="row">               
            <div class="col-md-12">
                <h3 class="text-center">Calendar</h3>
                <div class="month"> 
                    <ul>
                        <li>July<br><span style="font-size:18px">2018</span></li>
                    </ul>
                </div>
                <ul class="weekdays">
                    <li>Mo</li>
                    <li>Tu</li>
                    <li>We</li>
                    <li>Th</li>
                    <li>Fr</li>
                    <li>Sa</li>
                    <li>Su</li>
                </ul>
                <ul class="days"> 
                    <li title="Start of July"><b>1</b></li>
                    <li>2</li>
                    <li>3</li>
                    <li title="Fourth of July"><b>4</b></li>
                    <li>5</li>
                    <li>6</li>
                    <li>7</li>
                    <li>8</li>
                    <li>9</li>
                    <li>10</li>
                    <li>11</li>
                    <li>12</li>
                    <li>13</li>
                    <li>14</li>
                    <li>15</li>
                    <li>16</li>
                    <li>17</li>
                    <li>18</li>
                    <li>19</li>
                    <li>20</li>
                    <li>21</li>
                    <li>22</li>
                    <li title="Pokemon Camp Day 1"><b>23</b></li>
                    <li title="Pokemon Camp Day 2"><b>24</b></li>
                    <li title="Pokemon Camp Day 3"><b>25</b></li>
                    <li title="Pokemon Camp Day 4"><b>26</b></li>
                    <li title="Pokemon Camp Day 5"><b>27</b></li>
                    <li>28</li>
                    <li>29</li>
                    <li>30</li>
                    <li title="End of July"><b>31</b></li>
                </ul>
                <br>
                <br>
                <br>
                <style>

                
                    ul {list-style-type: none;}
                    body {font-family: Verdana, sans-serif;}

                    /* Month header */
                    .month {
                        padding: 20px 10px;
                        width: 100%;
                        background: #1abc9c;
                        text-align: center;
                    }

                    /* Month list */
                    .month ul {
                        margin: 0;
                        padding: 0;
                    }

                    .month ul li {
                        color: white;
                        font-size: 20px;
                        text-transform: uppercase;
                        letter-spacing: 3px;
                    }

                    /* Previous button inside month header */
                    .month .prev {
                        float: left;
                        padding-top: 10px;
                    }

                    /* Next button */
                    .month .next {
                        float: right;
                        padding-top: 10px;
                    }

                    /* Weekdays (Mon-Sun) */
                    .weekdays {
                        margin: 0;
                        padding: 10px 0;
                        background-color:#ddd;
                    }

                    .weekdays li {
                        display: inline-block;
                        width: 13.6%;
                        color: #666;
                        text-align: center;
                    }

                    /* Days (1-31) */
                    .days {
                        padding: 10px 0;
                        background: #eee;
                        margin: 0;
                    }

                    .days li {
                        list-style-type: none;
                        display: inline-block;
                        width: 13.6%;
                        text-align: center;
                        margin-bottom: 5px;
                        font-size:12px;
                        color: #777;
                    }

                    /* Highlight the "current" day */
                    .days li .active {
                        padding: 5px;
                        background: #1abc9c;
                        color: white !important
                    }

                </style>
            </div><!-- End of col-md-6 -->
        </div><!-- End of row -->
        <div class="row">
            <div class="col-md-12">
                <h3 class="text-center"><button id="myBtn">Weekly Events</button></h3>

                    <!-- Modal Code -->
                    <div id="myModal" class="modal">
                        <div class="modal-content">
                            <span class="close">&times;</span>
                            <p style="color:black">Make Sure to Go Check Out the Pokemon Sun and Moon Celestial Storm Pre-Release Tourney on July 21st on our <a href="https://www.facebook.com/events/481271222321281/" data-size="large" target="_blank">Facebook Page</a>
                            <br><br>After That We Will Have a Smash Bros Tournament on July 22nd, Go Check it Out On Our <a href="https://www.facebook.com/events/1698274260300528/" data-size="large" target="_blank">Facebook Page</a>
                            </p>
                        </div>
                    </div>

                    <style>
                        /* The Modal (background) */
                        .modal {
                            display: none; /* Hidden by default */
                            position: fixed; /* Stay in place */
                            z-index: 1; /* Sit on top */
                            padding-top: 100px; /* Location of the box */
                            left: 0;
                            top: 0;
                            width: 100%; /* Full width */
                            height: 100%; /* Full height */
                            overflow: auto; /* Enable scroll if needed */
                            background-color: rgb(0,0,0); /* Fallback color */
                            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
                        }

                        /* Modal Content */
                        .modal-content {
                            background-color: #fefefe;
                            margin: auto;
                            padding: 20px;
                            border: 1px solid #888;
                            width: 80%;
                        }

                        /* The Close Button */
                        .close {
                            color: #aaaaaa;
                            float: right;
                            font-size: 28px;
                            font-weight: bold;
                        }

                        .close:hover,
                        .close:focus {
                            color: #000;
                            text-decoration: none;
                            cursor: pointer;
                        }
                    </style>

                    <script>
                        // Get the modal
                        var modal = document.getElementById('myModal');

                        // Get the button that opens the modal
                        var btn = document.getElementById("myBtn");

                        // Get the <span> element that closes the modal
                        var span = document.getElementsByClassName("close")[0];

                        // When the user clicks the button, open the modal 
                        btn.onclick = function() {
                            modal.style.display = "block";
                        }

                        // When the user clicks on <span> (x), close the modal
                        span.onclick = function() {
                            modal.style.display = "none";
                        }

                        // When the user clicks anywhere outside of the modal, close it
                        window.onclick = function(event) {
                            if (event.target == modal) {
                                modal.style.display = "none";
                            }
                        }
                    </script>


                    <!-- End of Modal Code -->
                    <ol>
                        <li>Monday: Open Board Game Night & Star Wars X-Wing @ 5 pm</li>
                        <li>Tuesday: Magic @ 5 pm</li>
                        <li>Wednesday: WarHammer 40k @ 5 pm</li>
                        <li>Thursday: Open Board Game Night @ 5 pm</li>
                        <li>Friday: Dungeons and Dragons @ 5 pm</li>
                        <li>Saturday: Pokemon @ Noon / Yu-Gi-Oh @ 3 pm</li>
                    </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h3 class="text-center">Our Youtube Channel</h3>
                <center>
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/YMI0C0x7hN0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                </center>
            </div>
        </div>
        <br><br>
    </div><!-- End of Container -->













<?php include(TEMPLATE_FRONT . DS . "footer.php");  ?>